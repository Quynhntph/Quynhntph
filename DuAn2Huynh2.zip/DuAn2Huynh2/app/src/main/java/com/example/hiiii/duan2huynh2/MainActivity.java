package com.example.hiiii.duan2huynh2;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;


public class MainActivity extends AppCompatActivity {

    SeekBar sb_XeDap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sb_countDownTimer();

    }

    private void sb_countDownTimer(){
        sb_XeDap = findViewById(R.id.sb_XeDap);
        sb_XeDap.setEnabled(false);

        CountDownTimer countDownTimer = new CountDownTimer(10000, 300) {
            @Override
            public void onTick(long l) {
                sb_XeDap.setProgress(sb_XeDap.getProgress() + 5);
                if(sb_XeDap.getProgress() >= sb_XeDap.getMax()){
                    Intent intent = new Intent(MainActivity.this, ActivityOne.class);
                    startActivity(intent);
                }
            }

            @Override
            public void onFinish() {

            }
        };
        countDownTimer.start();
    }
}
