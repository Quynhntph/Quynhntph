package com.example.hiiii.duan2huynh2;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.hiiii.duan2huynh2.adapter.Custom_ABC;
import com.example.hiiii.duan2huynh2.model.Alphabet;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;


public class ActivityOne extends AppCompatActivity {
    ImageButton btnABC, btnAnimal, btnQuestion;
    ArrayList<Alphabet> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one);

        onclick_activity();

    }
    private void onclick_activity(){
        btnABC = findViewById(R.id.btn_ABC);
        btnAnimal = findViewById(R.id.btn_Animal);
        btnQuestion = findViewById(R.id.btn_Question);

        btnABC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ActivityOne.this, "Activity ABC", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ActivityOne.this, ActivityABC.class);
                startActivity(intent);
            }
        });
        btnAnimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ActivityOne.this, "Activity Animal", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ActivityOne.this, ActivityAnimal.class);
                startActivity(intent);
            }
        });
        btnQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ActivityOne.this, "Dialog question", Toast.LENGTH_SHORT).show();
                dialog_question();
            }
        });
    }

    private void dialog_question(){
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_custom);
        dialog.setCanceledOnTouchOutside(false);

        Button btn_QuestionABC = dialog.findViewById(R.id.btn_QuestionABC);
        btn_QuestionABC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ActivityOne.this, ActivityQuestion.class);
                startActivity(intent);
                dialog.dismiss();
            }
        });
        Button btn_back = dialog.findViewById(R.id.btn_back_dialog);
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

}
