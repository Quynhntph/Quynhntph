package com.example.hiiii.duan2huynh2.adapter;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.hiiii.duan2huynh2.R;
import com.example.hiiii.duan2huynh2.model.Alphabet;

import java.util.List;
import java.util.Locale;


public class Custom_ABC extends RecyclerView.Adapter<Custom_ABC.ViewHolder> {
    Context context;
    List<Alphabet> list;

    public Custom_ABC(Context context, List<Alphabet> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public Custom_ABC.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View itemView = layoutInflater.inflate(R.layout.custom_abc, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final Custom_ABC.ViewHolder holder, int position) {
        holder.tvName.setText(list.get(position).getName());
//        holder.tvId.setText(String.valueOf(list.get(position).getId()));
        Glide.with(context).load(list.get(position).getImage()).into(holder.imgbt_chu);
        holder.imgbt_chu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.textToSpeech = new TextToSpeech(context, new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int status) {
                        holder.textToSpeech.setLanguage(new Locale("ENG"));
                        holder.textToSpeech.speak(holder.tvName.getText().toString().trim(),
                                TextToSpeech.QUEUE_FLUSH, null);
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextToSpeech textToSpeech;
        private TextView tvName, tvId;
        private ImageButton imgbt_chu;
        public ViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_name);
//            tvId = itemView.findViewById(R.id.tv_id);
            imgbt_chu = itemView.findViewById(R.id.imgbt_chu);

        }
    }
}
