package com.example.hiiii.duan2huynh2.adapter;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.hiiii.duan2huynh2.R;
import com.example.hiiii.duan2huynh2.model.Animal;

import java.util.List;
import java.util.Locale;

public class Custom_Animal extends RecyclerView.Adapter<Custom_Animal.ViewHolder> {

    Context context;
    List<Animal> list;

    public Custom_Animal(Context context, List<Animal> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public Custom_Animal.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View itemView = layoutInflater.inflate(R.layout.custom_animal, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final Custom_Animal.ViewHolder holder, int position) {
        holder.tvName.setText(list.get(position).getName());
        Glide.with(context).load(list.get(position).getLinkimage())
                .into(holder.imgbt_Animal);
        holder.imgbt_Animal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.textToSpeech = new TextToSpeech(context, new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int status) {
                        holder.textToSpeech.setLanguage(new Locale("ENG"));
                        holder.textToSpeech.speak(holder.tvName.getText().toString().trim(),
                                TextToSpeech.QUEUE_FLUSH, null);
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextToSpeech textToSpeech;
        private TextView tvName;
        private ImageButton imgbt_Animal;

        public ViewHolder(View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_NameAnimal);
            imgbt_Animal = itemView.findViewById(R.id.imgbt_Animal);
        }
    }
}
