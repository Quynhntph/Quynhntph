package com.example.hiiii.duan2huynh2.model;

public class Alphabet {

    private String  name,image;

    public Alphabet() {
    }

    public Alphabet(String name, String image) {
        this.name = name;
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

}
