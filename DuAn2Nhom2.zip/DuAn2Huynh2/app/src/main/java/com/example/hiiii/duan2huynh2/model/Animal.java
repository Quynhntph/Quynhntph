package com.example.hiiii.duan2huynh2.model;

public class Animal {

     private String linkimage, name;

    public Animal(String linkimage, String name) {
        this.linkimage = linkimage;
        this.name = name;
    }

    public Animal() {
    }

    public String getLinkimage() {
        return linkimage;
    }

    public void setLinkimage(String linkimage) {
        this.linkimage = linkimage;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
