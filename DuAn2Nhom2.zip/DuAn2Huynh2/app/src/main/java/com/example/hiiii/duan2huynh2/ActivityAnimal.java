package com.example.hiiii.duan2huynh2;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.hiiii.duan2huynh2.adapter.Custom_Animal;
import com.example.hiiii.duan2huynh2.model.Animal;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ActivityAnimal extends AppCompatActivity {

    DatabaseReference mDataAnimal;

    Button btnAdmin;

    RecyclerView rc_Animal;
    Custom_Animal custom_animal;
    List<Animal> list;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal);

        btnAdmin = findViewById(R.id.btn_Admin);

        animal_DataFirebase();

        btnAdmin.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                dialog_Admin();
                return false;
            }
        });
    }

    private void dialog_Admin(){
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_login_admin);
        dialog.setCanceledOnTouchOutside(false);

        Button btnDongY = dialog.findViewById(R.id.btn_DongY);
        Button btnHuy = dialog.findViewById(R.id.btn_Huy);
        final EditText edUse= dialog.findViewById(R.id.edit_use);
        final EditText edPass = dialog.findViewById(R.id.edit_pass);

        btnDongY.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String use = edUse.getText().toString().trim();
                String pass = edPass.getText().toString().trim();
                if (use.equals("admin2019") && pass.equals("205duan2nhom2")){
                    Intent intent= new Intent(ActivityAnimal.this, ActivityAddAnimal.class );
                    startActivity(intent);
                    Toast.makeText(ActivityAnimal.this, "true", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                } else {
                    edUse.setText("");
                    edPass.setText("");
                    Toast.makeText(ActivityAnimal.this, "Sai mật khẩu và tài khoản", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnHuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }


    private void animal_DataFirebase(){
        mDataAnimal = FirebaseDatabase.getInstance().getReference();

        rc_Animal =  findViewById(R.id.rc_Animal);
        LinearLayoutManager layoutManager = new GridLayoutManager(this, 3);
        rc_Animal.setLayoutManager(layoutManager);
        list = new ArrayList<>();

        mDataAnimal.child("Animal").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Animal animal = dataSnapshot.getValue(Animal.class);
                list.add(new Animal(animal.getLinkimage(), animal.getName()));
                custom_animal = new Custom_Animal(getApplicationContext(), list);
                rc_Animal.setAdapter(custom_animal);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
