package com.example.hiiii.duan2huynh2;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.example.hiiii.duan2huynh2.adapter.Custom_ABC;
import com.example.hiiii.duan2huynh2.model.Alphabet;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class ActivityABC extends AppCompatActivity {
    DatabaseReference mDataABC;
    RecyclerView rc_ABC;
    Custom_ABC custom_abc;
    List<Alphabet> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abc);

        rc_ABC = findViewById(R.id.rc_ABC);
        LinearLayoutManager layoutManager = new GridLayoutManager(this, 3);
        rc_ABC.setLayoutManager(layoutManager);
        list = new ArrayList<>();

        xuatData();

    }


    private void xuatData(){
        mDataABC = FirebaseDatabase.getInstance().getReference();
        mDataABC.child("alphabet").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Alphabet alphabet = dataSnapshot.getValue(Alphabet.class);
                list.add(new Alphabet(alphabet.getName(), alphabet.getImage()));
                custom_abc = new Custom_ABC(getApplicationContext(),list );
                rc_ABC.setAdapter(custom_abc);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
