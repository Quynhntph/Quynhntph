package com.example.hiiii.duan2huynh2;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import com.example.hiiii.duan2huynh2.adapter.Custom_ABC;
import com.example.hiiii.duan2huynh2.adapter.Custom_QuestionABC;
import com.example.hiiii.duan2huynh2.model.Alphabet;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ActivityQuestion extends AppCompatActivity {
    DatabaseReference mDataQuestionABC;
    RecyclerView rc_QuestionABC;
    Custom_QuestionABC custom_questionABC;
    List<Alphabet> list;
    int IDS[] = new int[]{};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

        rc_QuestionABC = findViewById(R.id.rc_QuestionABC);
        LinearLayoutManager layoutManager = new GridLayoutManager(this, 3);
        rc_QuestionABC.setLayoutManager(layoutManager);
        list = new ArrayList<>();

        xuatData();

    }
    private void xuatData(){
        mDataQuestionABC = FirebaseDatabase.getInstance().getReference();
        mDataQuestionABC.child("alphabet").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Alphabet alphabet = dataSnapshot.getValue(Alphabet.class);
                list.add(new Alphabet(alphabet.getName(), alphabet.getImage()));
                custom_questionABC = new Custom_QuestionABC(getApplicationContext(),list );
                rc_QuestionABC.setAdapter(custom_questionABC);



                Random rd = new Random();
                for (int i =0; i < 7; i++){
                    int IDimg = IDS[rd.nextInt(IDS.length)];
                    list.add(new Alphabet(alphabet.getImage(), alphabet.getName()));
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
