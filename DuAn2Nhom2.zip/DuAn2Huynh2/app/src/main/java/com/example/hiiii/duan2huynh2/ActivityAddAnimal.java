package com.example.hiiii.duan2huynh2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.hiiii.duan2huynh2.adapter.Custom_Animal;
import com.example.hiiii.duan2huynh2.model.Animal;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ActivityAddAnimal extends AppCompatActivity {

    FirebaseStorage storage = FirebaseStorage.getInstance();
    DatabaseReference mDataAnimal;

    final  int RESQUEST_CODE_IMAGE = 123;
    final  int RESQUEST_CHOOSE_PHOTO = 321;

    ImageView imgAnh;
    EditText edName;
    Button btnChon, btnChup, btnSave;


    RecyclerView rc_addAnimal;
    Custom_Animal custom_animal;
    List<Animal> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_animal);

        anh_Xa();

        eventTake_Choose();

        addDataStore();

        animal_DataFirebase();

    }

    private void animal_DataFirebase(){
        mDataAnimal = FirebaseDatabase.getInstance().getReference();

        rc_addAnimal =  findViewById(R.id.rc_addAnimal);
        LinearLayoutManager layoutManager = new GridLayoutManager(this, 3);
        rc_addAnimal.setLayoutManager(layoutManager);
        list = new ArrayList<>();

        mDataAnimal.child("Animal").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Animal animal = dataSnapshot.getValue(Animal.class);
                list.add(new Animal(animal.getLinkimage(), animal.getName()));
                custom_animal = new Custom_Animal(getApplicationContext(), list);
                rc_addAnimal.setAdapter(custom_animal);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void addDataStore(){

        mDataAnimal = FirebaseDatabase.getInstance().getReference();
        final StorageReference storageRef = storage.getReferenceFromUrl("gs://duan2huynh2-9eb97.appspot.com");

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Calendar = lấy thời gian của hệ thống
                Calendar calendar = Calendar.getInstance();

                final StorageReference mountainsRef = storageRef.child("image" +  calendar.getTimeInMillis() + ".png");

                imgAnh.setDrawingCacheEnabled(true);
                imgAnh.buildDrawingCache();
                Bitmap bitmap = ((BitmapDrawable) imgAnh.getDrawable()).getBitmap();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
                byte[] data = baos.toByteArray();

                UploadTask uploadTask = mountainsRef.putBytes(data);
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        Toast.makeText(ActivityAddAnimal.this, "Lỗi !!! Không load dc ảnh", Toast.LENGTH_SHORT).show();
                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // lấy đường link ảnh
                        Task<Uri> urlTask = taskSnapshot.getStorage().getDownloadUrl();
                        while (!urlTask.isSuccessful());
                        Uri downloadUrl = urlTask.getResult();

                        Log.d("AAAAA", downloadUrl + "");
                        // tạo node trên phần database
                        Animal animal = new Animal(String.valueOf(downloadUrl), edName.getText().toString());
                        mDataAnimal.child("Animal").push().setValue(animal, new DatabaseReference.CompletionListener() {
                            @Override
                            public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                                if (databaseError == null){
                                    Toast.makeText(ActivityAddAnimal.this,
                                            "Save Data TRUE", Toast.LENGTH_SHORT).show();
                                    edName.setText("");
                                    imgAnh.setImageResource(R.drawable.icon_no_image);
                                } else {
                                    Toast.makeText(ActivityAddAnimal.this,
                                            "Fail Data", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                });
            }
        });
    }

    private void eventTake_Choose(){
        btnChon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, RESQUEST_CHOOSE_PHOTO);
            }
        });
        btnChup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, RESQUEST_CODE_IMAGE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == RESULT_OK){
            if(requestCode == RESQUEST_CHOOSE_PHOTO && resultCode == RESULT_OK && data!= null){
                try {
                    Uri imageURL = data.getData();
                    InputStream is = getContentResolver().openInputStream(imageURL);
                    Bitmap bitmap = BitmapFactory.decodeStream(is);
                    imgAnh.setImageBitmap(bitmap);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            } else if (requestCode == RESQUEST_CODE_IMAGE && resultCode == RESULT_OK && data != null){
                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                imgAnh.setImageBitmap(bitmap);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void anh_Xa(){
        imgAnh = findViewById(R.id.img_Animal_dl);
        btnChon = findViewById(R.id.btn_Chon_dl);
        btnChup = findViewById(R.id.btn_Chup_dl);
        btnSave = findViewById(R.id.btn_Save_dl);
        edName = findViewById(R.id.edit_Name_dl);
    }
}
