package com.example.hiiii.duan2huynh2;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fplashcreen();


    }
    private void fplashcreen(){
        Thread splashTread = new Thread() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000);
                } catch (Exception e) {

                } finally {
                    Intent intent = new Intent(MainActivity.this, ActivityOne.class);
                    startActivity(intent);
                }
            }
        };
        splashTread.start();
    }
}
