package com.example.hiiii.duan2huynh2.model;

public class Alphabet {

    public Alphabet(String image) {
        this.image = image;
    }

    public String  image;

    public Alphabet() {
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
