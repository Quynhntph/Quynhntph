package com.example.hiiii.duan2huynh2;
import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;


public class ActivityOne extends AppCompatActivity {
    ImageButton btn_ABC, btn_Animal, btn_Question;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one);

        btn_ABC = findViewById(R.id.btn_ABC);
        btn_Animal = findViewById(R.id.btn_Animal);
        btn_Question = findViewById(R.id.btn_Question);


        btn_ABC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ActivityOne.this, "Activity ABC", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ActivityOne.this, ActivityABC.class);
                startActivity(intent);
            }
        });
        btn_Animal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ActivityOne.this, "Activity Animal", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ActivityOne.this, ActivityAnimal.class);
                startActivity(intent);
            }
        });btn_Question.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ActivityOne.this, "Dialog question", Toast.LENGTH_SHORT).show();
                dialog_ct();
            }
        });
    }
    private void dialog_ct(){
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_custom);
        dialog.setCanceledOnTouchOutside(false);
        Button btn_back = dialog.findViewById(R.id.btn_back);
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
