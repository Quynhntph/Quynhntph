package com.example.hiiii.duan2huynh2.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.hiiii.duan2huynh2.R;
import com.example.hiiii.duan2huynh2.model.Alphabet;

import java.util.List;


public class Custom_ABC extends RecyclerView.Adapter<Custom_ABC.ViewHolder> {

    Context context;
    List<Alphabet> list;

    public Custom_ABC(Context context, List<Alphabet> list) {
        this.context = context;
        this.list = list;
    }



    @NonNull
    @Override
    public Custom_ABC.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View itemView = layoutInflater.inflate(R.layout.custom_abc, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull Custom_ABC.ViewHolder holder, int position) {
//        holder.tvName.setText(list.get(position).getName());
//        holder.tvId.setText(String.valueOf(list.get(position).getId()));
        Glide.with(context).load(list.get(position).getImage()).into(holder.imgbt_chu);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tvName, tvId;
        private ImageButton imgbt_chu;
        public ViewHolder(View itemView) {
            super(itemView);
//            tvName = itemView.findViewById(R.id.tv_name);
//            tvId = itemView.findViewById(R.id.tv_id);
            imgbt_chu = itemView.findViewById(R.id.imgbt_chu);

        }
    }
}
