package com.example.hiiii.duan2huynh2;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.hiiii.duan2huynh2.adapter.Custom_ABC;
import com.example.hiiii.duan2huynh2.model.Alphabet;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class ActivityABC extends AppCompatActivity {
    DatabaseReference mDataABC;
    RecyclerView rc_ABC;
    Custom_ABC custom_abc;
    List<Alphabet> list;

//    ArrayList<String> listABC;
//    ArrayAdapter adapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abc);

        rc_ABC = findViewById(R.id.rc_ABC);
//        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        LinearLayoutManager layoutManager = new GridLayoutManager(this, 3);
        rc_ABC.setLayoutManager(layoutManager);
        list = new ArrayList<>();
//        listABC = new ArrayList<String>();
//        adapter = new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1, listABC);
//        lv_ABC.setAdapter(adapter);

        back_activity();

        mDataABC = FirebaseDatabase.getInstance().getReference();

        mDataABC.child("alphabet").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Alphabet alphabet = dataSnapshot.getValue(Alphabet.class);
//                listABC.add(alphabet.id + " - " + alphabet.name);
//                adapter.notifyDataSetChanged();
                list.add(new Alphabet(alphabet.image));
                custom_abc = new Custom_ABC(getApplicationContext(),list );
                rc_ABC.setAdapter(custom_abc);

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void back_activity (){
        Button btn_back = findViewById(R.id.btn_back);
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ActivityABC.this, ActivityOne.class);
                startActivity(intent);
            }
        });
    }
}
